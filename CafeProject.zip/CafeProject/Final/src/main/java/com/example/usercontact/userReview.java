package com.example.usercontact;

import jakarta.servlet.ServletException;

import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

import com.example.Contact.Contact;
import com.example.ContactDAO.ReviewDAO;



public class userReview extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String Name = request.getParameter("name");
		String Email = request.getParameter("email");
		String Message = request.getParameter("message");
		
		Contact review = new Contact();
		review.setName(Name);
		review.setEmail(Email);
		review.setMesssage(Message);
		
		ReviewDAO reviewDAO = new ReviewDAO();
		if (reviewDAO.saveUser(review)) {
		response.sendRedirect("Successfull.jsp");
		}
		else {
		response.getWriter().println("Error saving user.");
		}
		}
		}

