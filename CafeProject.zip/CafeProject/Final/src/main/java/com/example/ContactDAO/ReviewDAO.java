package com.example.ContactDAO;

import java.sql.Connection;
import java.sql.PreparedStatement;

import com.example.Contact.Contact;
import com.example.Datacon.DataConnection;

public class ReviewDAO {
	public boolean saveUser(Contact review) {
    	String sql = "INSERT INTO review (name, email,message) VALUES (?,?,?)";
        
		// Establishing connection within a try-with-resources block to ensure it closes automatically
        try (Connection connection = DataConnection.getConnection();
        		 PreparedStatement statement = connection.prepareStatement(sql)) {
            // SQL query to insert user details
            
           
            // Setting parameters for the prepared statement
            statement.setString(1, review.getName());
            statement.setString(2, review.getEmail());
            statement.setString(3, review.getMesssage());

            // Executing the update
           int rowsInserted= statement.executeUpdate();
         System.out.println("Rows inserted:"+ rowsInserted);
         return rowsInserted > 0;
        } 
        catch (Exception e) {
            // Printing the stack trace for debugging in case of an error
            e.printStackTrace();
        }
        // Returning false if any exception occurs
        return false;
    }
}




