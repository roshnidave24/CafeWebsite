package com.example.bookController;

import jakarta.servlet.ServletException;

import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

import com.example.bookDao.DAObook;
import com.example.bookmodel.Book;



public class BookCon extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
			
			String name = request.getParameter("name");
			String phone = request.getParameter("phone");
			String time = request.getParameter("time");
			String date = request.getParameter("date");
			String guests = request.getParameter("guests");
			String specialrequest = request.getParameter("specialrequest");
			
			Book book = new Book();
			book.setName(name);
			book.setPhone(phone);
			book.setTime(time);
			book.setDate(date);
			book.setGuests(guests);
			book.setSpecialrequest(specialrequest);
			
			DAObook daobook = new DAObook();
			if (daobook.saveUser(book)) {
			response.sendRedirect("SuccessBook.jsp");
			}
			else {
			response.getWriter().println("Error saving user.");
			}
			}
			}

