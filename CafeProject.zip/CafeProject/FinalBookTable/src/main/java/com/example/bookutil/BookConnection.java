package com.example.bookutil;
import java.sql.Connection;
import java.sql.DriverManager;

public class BookConnection {
	

	 // Database connection details
    private static final String URL = "jdbc:mysql://localhost:3306/project";
    private static final String USER = "root";
    private static final String PASSWORD = "root";

    /**
     * Establishes and returns a connection to the database.
     * 
     * @return Connection object if successful, otherwise null
     */
    public static Connection getConnection() {
        try {
            // Load MySQL JDBC Driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Return connection
            return DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (Exception e) {
            // Print stack trace for debugging
            e.printStackTrace();
        }

        // Return null if connection fails
        return null;
    }
}


