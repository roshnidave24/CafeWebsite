package com.example.bookDao;

import java.sql.Connection;
import java.sql.PreparedStatement;

import com.example.bookmodel.Book;

import com.example.bookutil.BookConnection;

public class DAObook {
	
	public boolean saveUser(Book book) {
    	String sql = "INSERT INTO book (name,phone,time,date,guests,specialrequest) VALUES (?,?,?,?,?,?)";
        
		// Establishing connection within a try-with-resources block to ensure it closes automatically
        try (Connection connection = BookConnection.getConnection();
        		 PreparedStatement statement = connection.prepareStatement(sql)) {
            // SQL query to insert user details
            
           
            // Setting parameters for the prepared statement
           
            statement.setString(1, book.getName());
            statement.setString(2, book.getPhone());
            statement.setString(3, book.getTime());
            statement.setString(4, book.getDate());
            statement.setString(5, book.getGuests());
            statement.setString(6, book.getSpecialrequest());



            // Executing the update
           int rowsInserted= statement.executeUpdate();
         System.out.println("Rows inserted:"+ rowsInserted);
         return rowsInserted > 0;
        } 
        catch (Exception e) {
            // Printing the stack trace for debugging in case of an error
            e.printStackTrace();
        }
        // Returning false if any exception occurs
        return false;
    }
}



