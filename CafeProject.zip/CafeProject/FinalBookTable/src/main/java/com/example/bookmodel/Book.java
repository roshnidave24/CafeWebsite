package com.example.bookmodel;

public class Book {
	private String name;
	private String phone;
	private String time;
	private String date;
	private String guests;
	private String specialrequest;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getGuests() {
		return guests;
	}
	public void setGuests(String guests) {
		this.guests = guests;
	}
	public String getSpecialrequest() {
		return specialrequest;
	}
	public void setSpecialrequest(String specialrequest) {
		this.specialrequest = specialrequest;
	}
	public Book(String name, String phone, String time, String date, String guests, String specialrequest) {
		super();
		this.name = name;
		this.phone = phone;
		this.time = time;
		this.date = date;
		this.guests = guests;
		this.specialrequest = specialrequest;
	}
	public Book() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Book [name=" + name + ", phone=" + phone + ", time=" + time + ", date=" + date + ", guests=" + guests
				+ ", specialrequest=" + specialrequest + "]";
	}
	
	
	
	

}
