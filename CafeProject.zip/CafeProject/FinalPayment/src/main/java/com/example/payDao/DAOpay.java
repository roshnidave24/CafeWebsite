package com.example.payDao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import com.example.paymodel.Pay;
import com.example.payutil.PayConnection;

public class DAOpay {

    public boolean savePayment(Pay pay) {
        String sql = "INSERT INTO pay (cardNumber, expiryDate, cvv, cardHolderName, totalAmount) VALUES (?,?,?,?,?)";
        
        try (Connection connection = PayConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            
            // Check for null values in pay object
            if (pay == null) {
                throw new IllegalArgumentException("Payment data is null.");
            }

            // Check each field and ensure it's not null or empty
            if (pay.getCardNumber() == null || pay.getCardNumber().isEmpty()) {
                throw new IllegalArgumentException("Card number is required.");
            }
            if (pay.getExpiryDate() == null || pay.getExpiryDate().isEmpty()) {
                throw new IllegalArgumentException("Expiry date is required.");
            }
            if (pay.getCvv() == null || pay.getCvv().isEmpty()) {
                throw new IllegalArgumentException("CVV is required.");
            }
            if (pay.getCardHolderName() == null || pay.getCardHolderName().isEmpty()) {
                throw new IllegalArgumentException("Cardholder name is required.");
            }
            if (pay.getTotalAmount() == null || pay.getTotalAmount().isEmpty()) {
                throw new IllegalArgumentException("Total amount is required.");
            }

            // Ensure the totalAmount is a valid numeric value (no commas, only numeric and decimal)
            try {
                Double.parseDouble(pay.getTotalAmount());  // This ensures it's a valid number
            } catch (NumberFormatException e) {
                throw new IllegalArgumentException("Invalid total amount format.");
            }

            // Set the prepared statement parameters
            statement.setString(1, pay.getCardNumber());
            statement.setString(2, pay.getExpiryDate());
            statement.setString(3, pay.getCvv());
            statement.setString(4, pay.getCardHolderName());
            statement.setString(5, pay.getTotalAmount());

            // Execute the query
            int rowsInserted = statement.executeUpdate();
            System.out.println("Rows inserted: " + rowsInserted);

            // If at least one row was inserted, return true
            return rowsInserted > 0;
        } catch (IllegalArgumentException e) {
            // Log validation errors (invalid or missing fields)
            System.err.println("Validation Error: " + e.getMessage());
            e.printStackTrace();
        } catch (SQLException e) {
            // Log SQL exceptions (issues with database query execution or connectivity)
            System.err.println("SQL Error occurred while saving payment: " + e.getMessage());
            e.printStackTrace();
        } catch (Exception e) {
            // Log other exceptions (unexpected errors)
            System.err.println("Error occurred while saving payment: " + e.getMessage());
            e.printStackTrace();
        }
        return false;
    }
}
