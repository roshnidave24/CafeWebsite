package com.example.payutil;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class PayConnection {

    // Database connection details
    private static final String URL = "jdbc:mysql://localhost:3306/project";
    private static final String USER = "root";
    private static final String PASSWORD = "root";

    /**
     * Establishes and returns a connection to the database.
     * 
     * @return Connection object if successful, otherwise null
     */
    public static Connection getConnection() {
        try {
            // Load MySQL JDBC Driver (for compatibility)
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Return connection
            return DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (ClassNotFoundException e) {
            // Log the error for missing JDBC driver
            System.err.println("MySQL JDBC Driver not found: " + e.getMessage());
        } catch (SQLException e) {
            // Log any SQL connection errors
            System.err.println("Error establishing database connection: " + e.getMessage());
        } catch (Exception e) {
            // Log any other unexpected errors
            System.err.println("Unexpected error: " + e.getMessage());
        }

        // Return null if connection fails
        return null;
    }
}
