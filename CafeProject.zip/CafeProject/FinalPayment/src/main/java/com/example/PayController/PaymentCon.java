package com.example.PayController;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

import com.example.payDao.DAOpay;
import com.example.paymodel.Pay;

public class PaymentCon extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve form parameters
        String cardNumber = request.getParameter("cardNumber");
        String expiryDate = request.getParameter("expiryDate");
        String cvv = request.getParameter("cvv");
        String cardHolderName = request.getParameter("cardHolderName");
        String totalAmount = request.getParameter("totalAmount");

        // Log parameters for debugging
        System.out.println("Received payment details:");
        System.out.println("Card Number: " + cardNumber);
        System.out.println("Expiry Date: " + expiryDate);
        System.out.println("CVV: " + cvv);
        System.out.println("Card Holder Name: " + cardHolderName);
        System.out.println("Total Amount: " + totalAmount);

       
        // Create Pay object and set its properties
        Pay pay = new Pay();
        pay.setCardNumber(cardNumber);
        pay.setExpiryDate(expiryDate);
        pay.setCvv(cvv);
        pay.setCardHolderName(cardHolderName);
        pay.setTotalAmount(totalAmount);

        // Initialize DAOpay and save payment
        DAOpay daopay = new DAOpay();
        boolean paymentSaved = daopay.savePayment(pay);
        
        if (paymentSaved) {
            response.sendRedirect("SuccessPayment.jsp");  // Redirect to success page if payment is saved
        } else {
            // Log failure message and show user an error message
            System.err.println("Error processing payment.");
            response.getWriter().println("Error processing payment.");
        }
    }
}
