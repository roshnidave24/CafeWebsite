package com.example.paymodel;

public class Pay {
	

	 private String cardNumber;
	    private String expiryDate;
	    private String cvv;
	    private String cardHolderName;
	    private String totalAmount;
		public String getCardNumber() {
			return cardNumber;
		}
		public void setCardNumber(String cardNumber) {
			this.cardNumber = cardNumber;
		}
		public String getExpiryDate() {
			return expiryDate;
		}
		public void setExpiryDate(String expiryDate) {
			this.expiryDate = expiryDate;
		}
		public String getCvv() {
			return cvv;
		}
		public void setCvv(String cvv) {
			this.cvv = cvv;
		}
		public String getCardHolderName() {
			return cardHolderName;
		}
		public void setCardHolderName(String cardHolderName) {
			this.cardHolderName = cardHolderName;
		}
		public String getTotalAmount() {
			return totalAmount;
		}
		public void setTotalAmount(String totalAmount) {
			this.totalAmount = totalAmount;
		}
		public Pay(String cardNumber, String expiryDate, String cvv, String cardHolderName, String totalAmount) {
			super();
			this.cardNumber = cardNumber;
			this.expiryDate = expiryDate;
			this.cvv = cvv;
			this.cardHolderName = cardHolderName;
			this.totalAmount = totalAmount;
		}
		public Pay() {
			super();
			// TODO Auto-generated constructor stub
		}
		@Override
		public String toString() {
			return "Pay [cardNumber=" + cardNumber + ", expiryDate=" + expiryDate + ", cvv=" + cvv + ", cardHolderName="
					+ cardHolderName + ", totalAmount=" + totalAmount + "]";
		}


	   

}